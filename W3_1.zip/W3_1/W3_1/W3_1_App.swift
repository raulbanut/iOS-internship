//
//  W3_1App.swift
//  W3_1
//
//  Created by Banut Raul on 14.03.2022.
//

import SwiftUI

@main
struct W3_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
